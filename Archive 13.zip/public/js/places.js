// $(function() {
//
//   var nyc = "https://www.google.com/maps/d/u/0/embed?mid=1iOUPhAu94OqaIHJblfxF56T-87U",
//       la = "https://www.google.com/maps/d/u/0/embed?mid=1y2YtXXhuADTgyL0hDTJhd2Ev19Y",
//       madison = "https://www.google.com/maps/d/u/1/viewer?authuser=1&mid=1BIVSc9-PR7Lpl9lKoVovq6Kbszg";
//
//   $("#madison").hide();
//   $("#la").hide();
//
//   function changeLocations(dest) {
//     switch (dest) {
//       case "nyc":
//         $("iframe").fadeOut("fast", function() {
//           $("#nyc").fadeIn("fast");
//         });
//       break;
//       case "la":
//         $("iframe").fadeOut("fast", function() {
//           $("#la").fadeIn("fast");
//         });
//       break;
//       case "madison":
//         $("iframe").fadeOut("fast", function() {
//           $("#madison").fadeIn("fast");
//         });
//       break
//     }
//   };
//
// });
